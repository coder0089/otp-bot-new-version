# New Version Of Simple My OTP Bot 

    Simple OTP Bot, working with any company or service name.
    New OTP Bot, working with any company or service name to fetch otp code.

![See the bot in action](https://user-images.githubusercontent.com/117955242/203935966-e3e8ee3c-384b-448d-b86b-d5189d66b585.png)

    Send command: "/dial" to start grabbing your OTP

# THIS SOURCE CODE IS FREE AND FOR EDUCATION PURPOSE ONLY.

    For Step-By-Step Installation Process Join My Discord Server.
    And For more advanced Discord and Telegram OTP Bots.


# For Customization or Private OTP Bots Contact me on my new Chennel and Server

    Discord Server:  https://discord.gg/CVgscsvRRx
    Telegram Channel https://t.me/+I2QcslRt8HM2YTEx
    DM Discord: Coder089#8305
    DM Telegram: @Coder0089
Discord Server: https://discord.gg/CVgscsvRRx

NEW Telegram Channel https://t.me/+I2QcslRt8HM2YTEx

Old Telegram Channel https://t.me/+fzkvq8FdnQY2ZmNh

    (Old Channels are Banned)
    https://discord.gg/ghHtyDevI
    https://t.me/+uftsns3gsKhdLfc1tUy
    https://t.me/+fzkvq8FdnQY2ZmNh


# Buy me coffee: 

    Ethereum: 0x06F0ff15A132410389C41fd4B52c9E458666F579
    Bitcoin: bc1qw9rzd4ze0c43fklj2hnlzrtw3ps7mx7w5pl7mk
    BNB: bnb19l2tz4y5jlwdtrk0v9jkenhmv05kuy2y327mv9
    LTC: ltc1qs89vzwyete5jnn5mcpqp2zvrlzv8gdwq0a4tt6
  
  
  # SETUP
    
    Download ngrok and run ngrok.exe http 5000
    Download python and Install
    Unzip Your Bot files

    pip3 install discord
    pip install Flask
    pip install discord-py-slash-command
    pip install twilio
    
    # First create a discord group
    Go to your discord developer page  https://discord.com/developers/applications/
    Click "New Application", create application
    Click "OAuth2"
    Click "URL Generator"**
    
     # OAuth2 URL Generator Page

     # SCOPE
     Check "Bot"
     Check "applications.commands"

     # BOT PERMISSIONS
     Check All Permissions
     Dont check "Administrator"

     # GENERATED URL
     Copy the URL
     Open new Tab in your browser where you logged your discord
     Paste the URL and follow it, authorize the Bot in your group.
     Go back to to your discord developer Tab
     Left side, click "Bot" and click "add" Bot
     Left side, click "Bot" and click "add" Bot
     Click "Reset Token" and click "Copy" to copy token
     Open "bot.py" add bot_token
     Go to discord server/group 
     Left side, right-click on the server and click "copy ID"
     Go to "bot.py" add server_id

     # Twilio Details
     Go to Twilio Account Copy "Account SID" 
     Go to "bot.py" add account_sid
     Go to Twilio Account again Copy "Auth Token" 
     Go to "bot.py" add auth_token
     Go to Twilio Account again Copy "Your Twilio Phone Number" 
     Go to "bot.py" add Twilio Phone Number (e.g "+1987654321")
     Go to terminal where you run ngron, copy your https link/url
     Go to "bot.py" add ngrok_url
     Save bot.py, close file and run bot.py in python
     Run talker.py in python

     # Start Calling
     Go to your server and type command: "/dial" and fill your info.
     E.G: /dial cell_phone:+1987654321 otp_digits:6 client_name:Smith company_name:PayPal

     # Error
     DM or Join Channels
